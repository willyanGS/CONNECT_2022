var botao = document.getElementById("botao");
botao.addEventListener("click", () => {botao.innerText = "Meu segundo botão"});